package LeetcodeProblems;


import LinkedList.LL;

public class LeetCode {

    //https://leetcode.com/problems/reorder-list/
    public void reorderList(ListNode head) {
        if(head == null || head.next == null){
            return;
        }

        ListNode mid = middleNode(head);

        ListNode hs = reverseIterative(mid);
        ListNode hf = head;

        while(hf != null && hs != null){
            ListNode temp = hf.next;
            hf.next = hs;
            hf = temp;

            temp = hs.next;
            hs.next = hf;
            hs = temp;
        }
        if(hf != null){
            hf.next = null;
        }
    }

    //https://leetcode.com/problems/palindrome-linked-list/submissions/
    public boolean isPalindrome(ListNode head){
        ListNode mid = middleNode(head);
        ListNode secondHead = reverseIterative(mid);
        ListNode reverseHead = secondHead;

        while(head != null && secondHead != null){
            if(head.val != secondHead.val)
                break;
            head = head.next;
            secondHead = secondHead.next;
        }

        reverseIterative(reverseHead);
        if(head == null || secondHead == null)
            return true;
        return false;
    }

    public ListNode middleNode(ListNode head) {
        ListNode slow = head;
        ListNode fast = head;

        while(fast != null && fast.next != null){
            fast = fast.next.next;
            slow = slow.next;
        }
        return slow;
    }

    public ListNode reverseIterative(ListNode node){
        if(node == null){
            return node;
        }
        ListNode prev = null;
        ListNode present = node;
        ListNode next = present.next;

        while (present != null){
            present.next = prev;
            prev = present;
            present = next;
            if(next != null) {
                next = next.next;
            }
        }
//        head = prev;
        return prev;
    }

    public class ListNode {
      int val;
      ListNode next;
      ListNode() {
      }

      ListNode(int val) {
          this.val = val;
      }

      ListNode(int val, ListNode next) {
          this.val = val; this.next = next;
      }
  }
}
