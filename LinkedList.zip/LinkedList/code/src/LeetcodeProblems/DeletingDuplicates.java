package LeetcodeProblems;

public class DeletingDuplicates {
    public static void main(String[] args) {
        LL ll = new LL();

        ll.insertLast(1);
        ll.insertLast(1);
        ll.insertLast(2);
        ll.insertLast(2);
        ll.insertLast(3);
        ll.insertLast(4);
        ll.display();

        ll.deleteDuplicates();
        ll.display();
    }
}
