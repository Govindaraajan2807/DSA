package CLL;

public class MainCLL {
    public static void main(String[] args) {
        CLL cll = new CLL();
        cll.insert(1);
        cll.insert(2);
        cll.insert(3);
        cll.insert(4);
        cll.insert(5);
        cll.insert(6);
        cll.insert(7);
        cll.insert(8);

        cll.display();

//        cll.delete(40);
//        cll.display();
    }
}
