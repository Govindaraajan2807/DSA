package SLL;

public class Main {

    public static void main(String[] args) {
//        LL ll = new LL();
//        System.out.println("-----------> inserting to first index");
//        ll.insertFirst(3);
//        ll.insertFirst(5);
//        ll.insertFirst(8);
//        ll.insertFirst(14);
//        ll.display();
//        System.out.println();

//        System.out.println("-----------> inserting to last index");
//        ll.insertLast(3);
//        ll.insertLast(5);
//        ll.insertLast(8);
//        ll.insertLast(14);
//        ll.display();
//        System.out.println();
//
//        System.out.println("-----------> inserting to 2nd index");
//        ll.insert(100,2);
//        ll.display();
//        System.out.println();

//        System.out.println("-----------> deleting first index");
//        System.out.println(ll.deleteFirst());
//        ll.display();
//        System.out.println();

//        System.out.println("-----------> deleting last index");
//        System.out.println(ll.deleteLast());
//        ll.display();
//        System.out.println();
//        System.out.println(ll.delete(2));
//        ll.display();

//        System.out.println("-----------> inserting using recursion");
//        ll.insertRec(88,2);
//        ll.display();

        LeetcodeProblems.LL first = new LeetcodeProblems.LL();
        LeetcodeProblems.LL second = new LeetcodeProblems.LL();

        first.insertLast(1);
        first.insertLast(3);
        first.insertLast(5);

        second.insertLast(1);
        second.insertLast(2);
        second.insertLast(9);
        second.insertLast(15);

        LeetcodeProblems.LL ans = LeetcodeProblems.LL.merge(first,second);
        ans.display();

    }
}
