package com.Govind.Stack;

public class StackException extends Exception {
    public StackException(String message) {
        super(message);

    }
}
