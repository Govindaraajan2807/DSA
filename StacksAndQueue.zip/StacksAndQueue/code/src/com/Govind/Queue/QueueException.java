package com.Govind.Queue;

public class QueueException extends Exception{
    public QueueException(String message) {
        super(message);
    }
}
